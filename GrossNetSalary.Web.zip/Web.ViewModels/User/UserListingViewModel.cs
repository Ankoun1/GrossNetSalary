﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.ViewModels.Salary;

namespace Web.ViewModels.User
{
    public class UserListingViewModel
    {
        public string Id { get; init; }

        public string FullName { get; init; }

        public string Email { get; init; }
        
    }
}
