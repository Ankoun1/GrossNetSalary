﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Web.ViewModels.Constants.GlobalConstants.UserConstants;

namespace Web.ViewModels.User
{
    public class UserUpdateFormModel
    {
        [Required]
        [StringLength(PasswordMaxLength, MinimumLength = PasswordMinLength)]
        public string NewPassword { get; init; }        
        
        [EmailAddress]
        public string NewEmail { get; init; }
    }
}
