﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web.ViewModels.Salary
{
    public class OnlainPaymentFormModel
    {
        [Range(0, 15000)]
        public decimal GrossSalary { get; init; }
    }
}
