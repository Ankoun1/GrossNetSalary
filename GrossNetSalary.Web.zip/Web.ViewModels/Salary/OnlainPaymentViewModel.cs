﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web.ViewModels.Salary
{
    public class OnlainPaymentViewModel
    {
        public decimal Gross { get; set; }

        public decimal Net { get; set; }
    }
}
