﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.ViewModels.Salary;

namespace BL.Salary
{
    public interface ISalaryBL
    {
        void UseParameters(SalaryParametersFormModel parameters);

        void GenerateMonths();

        bool InvalidYear();

        bool ExistingSalary(string userId, int month);

        void SalarySummation(string email,decimal grossSalary,int month);

        decimal CalculatorOnlain(OnlainPaymentFormModel salary);
    }
}
