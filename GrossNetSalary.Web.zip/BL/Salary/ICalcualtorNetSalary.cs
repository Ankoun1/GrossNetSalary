﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL.Salary
{
    public interface ICalcualtorNetSalary
    {
        decimal Calculate(decimal grossSalary, int incomeTax, int healthAndSocialInsurance, int minInsuranceThreshold, int maxInsuranceThreshold);
    }
}
