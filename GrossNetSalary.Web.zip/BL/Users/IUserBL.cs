﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using DAL.Repository.Models;
using Microsoft.AspNetCore.Identity;
using Web.ViewModels.Salary;
//using Microsoft.AspNetCore.Mvc;
using Web.ViewModels.User;

namespace BL.Users
{
    public interface IUserBL
    {
        Task<IdentityResult> CreateRoleAdmin();

        Task<IdentityResult> CreateUser(UserFormModel user);

        Task<IdentityResult> UpdateUser(string id,UserUpdateFormModel user);
        
        void DeleteUser(string userId);             

        List<UserListingViewModel> GetUsers();

        List<UserInformationViewModel> UserInfo(string userId);

        bool EmailVerification(string email);

        Task<bool> CheckPassword(string email, string password);

        bool UserExist(string userId);

        bool UserIsDeleted(string email);

        AplicationUser ExistingUser(string email);

        string GetUserId(string email);        

        bool VerificationAdmin(UserFormModel userModel);

        Task<SignInResult> SignIn(string email, string password);

        void SignOut();
    }
}
